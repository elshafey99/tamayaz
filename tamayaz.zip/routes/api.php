<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\CarController;
use App\Http\Controllers\Api\LoginController;
use App\Http\Controllers\Api\LogoutController;
use App\Http\Controllers\Api\AuctionController;
use App\Http\Controllers\Api\CountryController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\PasswordController;
use App\Http\Controllers\Api\QuestionController;
use App\Http\Controllers\Api\RegisterController;
use App\Http\Controllers\Api\InsuranceController;
use App\Http\Controllers\Api\MyAuctionController;
use App\Http\Controllers\Api\TypePaymentController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\CommitAuctionController;
use App\Http\Controllers\Api\PrivacyPolicyController;
use App\Http\Controllers\Api\StripeWebhookController;
use App\Http\Controllers\Api\WithdrawMoneyController;
use App\Http\Controllers\Api\ChangeLanguageController;
use App\Http\Controllers\Api\BalanceInsuranceController;
use App\Http\Controllers\Api\MaintenanceCenterController;


// register
Route::post("/register", [RegisterController::class ,'register']);

// verify
Route::post('/verify', [RegisterController::class, 'verify']);
Route::post('/otp', [RegisterController::class, 'otp']);
//login
Route::post("/login", [LoginController::class ,'login']);
//forget-password
Route::post('/forget-password', [PasswordController::class, 'forgetPassword']);
//confirmationOtp
Route::post('/confirmation-otp', [PasswordController::class, 'confirmationOtp']);
//reset-password
Route::post('/reset-password', [PasswordController::class, 'resetPassword']);


Route::group(['middleware' => ['auth:sanctum']], function () {
    // user
    Route::get('/profile', [ProfileController::class, 'profile']);
    Route::post('/profile', [ProfileController::class, 'updateProfile']);
    Route::post('/change-password', [PasswordController::class, 'changePassword']);
    Route::post('/logout', [LogoutController::class, 'logout']);

});

