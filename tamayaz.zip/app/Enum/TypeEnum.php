<?php

namespace App;

enum TypeEnum
{

}
