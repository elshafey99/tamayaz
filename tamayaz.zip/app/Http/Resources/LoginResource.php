<?php

namespace App\Http\Resources;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LoginResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
{
    $student = User::where('type', 'parent')->where('code_student', $this->code_student)->first();

    $data = [
        "id" => $this->id,
        'name' => $this->name,
        'email' => $this->email,
        'type' => $this->type,
        'brithdate' => $this->brithdate,
        'grade_id' => $this->grade->name,
        'stage_id' => $this->stage->name,
        'image' => $this->image,
        'code_student' => $this->code_student,
    ];

    if ($student) {
        $data['student'] = StudentResource::make($student);
    }

    return $data;
}

}
