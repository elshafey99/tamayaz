<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RegisterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        // بيانات الطالب (student) إذا كان اليوزر الحالي هو parent
        $student = null;

        if ($this->type === 'parent' && $this->code_student) {
            $student = \App\Models\User::where('code_student', $this->code_student)->first();
        }

        return [
            "id" => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'type' => $this->type,
            'brithdate' => $this->brithdate,
            'grade_id' => $this->grade?->name,
            'stage_id' => $this->stage?->name,
            'code_student' => $this->code_student,
            'image' => $this->image,

            // إرجاع بيانات الطالب إذا وُجد
            'student' => $student ? [
                'id' => $student->id,
                'name' => $student->name,
                'email' => $student->email,
                'brithdate' => $student->brithdate,
                'grade' => $student->grade?->name,
                'stage' => $student->stage?->name,
                'image' => $student->image,
            ] : null,
        ];
    }

}
