<?php $__env->startSection('contact'); ?>
    <div class="alert alert-danger text-center">
        <h3><?php echo e($message); ?></h3>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary mt-3">رجوع</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tamayaz\resources\views/errors/insurance-not-found.blade.php ENDPATH**/ ?>