<?php

namespace Database\Seeders;

use App\Models\Grade;
use App\Models\Stage;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class GradeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Example stages: Primary, Preparatory, Secondary
        $stages = [
            'Primary',
            'Preparatory',
            'Secondary',
        ];

        foreach ($stages as $stageName) {
            // Make sure the stage exists or create it
            $stage = Stage::firstOrCreate(['name' => $stageName]);

            // Add 3 grades for each stage
            for ($i = 1; $i <= 3; $i++) {
                Grade::create([
                    'stage_id' => $stage->id,
                    'name' => "Grade $i - $stageName Stage",
                ]);
            }
        }
    }
}
